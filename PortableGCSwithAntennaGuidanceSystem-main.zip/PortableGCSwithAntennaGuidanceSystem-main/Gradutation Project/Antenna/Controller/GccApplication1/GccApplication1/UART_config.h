/*
 * UART_config.h
 *
 * Created: 4/19/2021 10:49:08 PM
 *  Author: MohammedGamalEleish
 */ 


#ifndef UART_CONFIG_H_
#define UART_CONFIG_H_


#define UART_SYSTEM_CLOCK		16000000UL


#endif /* UART_CONFIG_H_ */