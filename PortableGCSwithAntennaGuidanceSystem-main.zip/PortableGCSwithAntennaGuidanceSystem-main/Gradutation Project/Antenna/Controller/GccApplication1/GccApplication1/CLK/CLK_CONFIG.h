/*
 * CLK_CONFIG.h
 *
 * Created: 4/25/2021 3:01:39 AM
 *  Author: ahmed
 */ 


#ifndef CLK_CONFIG_H_
#define CLK_CONFIG_H_


#define FOSC 16000000


#endif /* CLK_CONFIG_H_ */