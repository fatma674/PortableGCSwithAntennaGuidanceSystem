/*
 * std_types.h
 *
 * Created: 11/3/2020 6:09:15 AM
 *  Author: ahmed
 */ 


#ifndef _STD_TYPES_H_
#define _STD_TYPES_H_

typedef unsigned char u8;
typedef unsigned short int u16;
typedef unsigned long int u32;

#endif /* STD-TYPES_H_ */