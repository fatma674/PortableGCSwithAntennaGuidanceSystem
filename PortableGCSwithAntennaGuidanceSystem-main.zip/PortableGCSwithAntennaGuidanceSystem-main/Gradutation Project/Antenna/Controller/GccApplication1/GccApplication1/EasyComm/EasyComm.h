/*
 * EasyComm.h
 *
 * Created: 4/19/2021 1:55:10 AM
 *  Author: ahmed
 */ 


#ifndef EASYCOMM_H_
#define EASYCOMM_H_


void EasyComm_voidParseCmd(u8 cmd[], u8 *resp);


#endif /* EASYCOMM_H_ */