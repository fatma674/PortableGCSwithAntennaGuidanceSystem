#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#include "STD_TYPES.h"
#include "BIT_MATH.h"
#include "UART.h"

#include "DATALINK_interface.h"


int main()
{
    //Uart Init

    return 0;
}
