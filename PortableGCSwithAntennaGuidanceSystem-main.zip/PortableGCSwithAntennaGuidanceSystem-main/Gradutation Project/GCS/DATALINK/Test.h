#ifndef TEST_H_INCLUDED
#define TEST_H_INCLUDED

void TestSimplexStateMachine(void);
void TestDuplexStateMachine(void);
void TestDataLinkStateMachine(void);
void Test_DL_PH(void);
#endif // TEST_H_INCLUDED
