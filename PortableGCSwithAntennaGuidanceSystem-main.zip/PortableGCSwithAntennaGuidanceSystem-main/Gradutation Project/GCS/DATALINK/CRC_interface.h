/*
 * CRC_interface.h
 *
 *  Created on: Jan 4, 2021
 *      Author: MohammedGamalEleish
 */

#ifndef CRC_INTERFACE_H_
#define CRC_INTERFACE_H_

u16 CRC16_u16CCITTFalse(u8* Copy_u8PtrData, u32 Copy_u32DataLength);

#endif /* CRC_INTERFACE_H_ */
