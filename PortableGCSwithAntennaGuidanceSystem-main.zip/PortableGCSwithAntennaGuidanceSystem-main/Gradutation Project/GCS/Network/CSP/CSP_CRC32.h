#ifndef CSP_CRC32_H_INCLUDED
#define CSP_CRC32_H_INCLUDED
#include "STD.h"
u32 CSP_CRC32(u8* dataptr,u16 datalength);

#endif // CSP_CRC32_H_INCLUDED
